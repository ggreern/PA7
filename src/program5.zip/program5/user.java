
package program5;

import java.util.*;
import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;


public class user {

    private String firstname;
    private String lastname;
    private String userId;
    private String password;
    

    public user() {
        firstname = "FIRST";
        lastname = "LAST";
        userId = "Unknown";
        password = "Unknown";
    }
    
    public user(String firstname, String lastname, String userId, String password) {
        setFirstname(firstname);
        setLastname(lastname);
        setUserId(userId);
        setPassword(password);
    
}
    public String userInfo(boolean x) {
        String info = "";
        if (x) {
            info += "First Name: " + firstname;
            info += "\nLast Name: " + lastname;
            info += "\nUser ID: " + userId;
            info += "\nPassword: " + password;
        }
        else
        {
            info += firstname + " " + lastname;
        }
        return info;
    }
    
    public boolean equals(String x) {
        String[] fullName = x.split(" ");
        String firstName = fullName[0];
        String lastName = fullName[1];
        return this.firstname.equalsIgnoreCase(firstName) && this.lastname.equalsIgnoreCase(lastName);
    }
    
    public String getFirstname() {
        return firstname;
    }
    
    public void setFirstname(String firstname) {
        this.firstname = firstname.substring(0,1).toUpperCase() + firstname.substring(1).toLowerCase();
    }
    
    public String getLastname() {
        return lastname;
    }
    
    public void setLastname(String lastname) {
        this.lastname = lastname.substring(0,1).toUpperCase() + lastname.substring(1).toLowerCase();
    }
    
    public String getUserId() {
        return userId;
    }
    
    public void setUserId(String userId) {
        if (Character.isLetter(userId.charAt(0)) && userId.matches("^[a-zA-z][a-zA-Z0-9]*$")) {
            this.userId = userId;
        }
        else {
            this.userId = "Unkown";
        }
    }
    
    public String getPassword() {
        return password;
    }
    
    private boolean isValidPassword(String password) {
        String pattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        return password.matches(pattern);
    }
    
    public void setPassword(String password) {
        if (isValidPassword(password)) {
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte[] hash = md.digest(password.getBytes());
                this.password = toHexString(hash);
            }
            catch (noSuchAlgorithmException e) {
                
            }   
        }
        else {
            this.password = "Unknown";
        }
    }
    
    private static String toHexString (byte[] hash) {
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
    
    
}
